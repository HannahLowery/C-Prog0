//a C program that prompts a user for an interger, then accepts n strings from standard input.

//Author :Hannah Lowery
//Compile: gcc -Wall -o prog1 prog1.c
//execute: ./prog1


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//The buffersize so the input can be no longer than 1024
#define BUFSIZE 1024

//my comparator method to compare the strings for the qsort() method
int cmp(const void *p1, const void *p2) {
    const char *a = *(const char **)p1;
    const char *b = *(const char **)p2;
    return strcmp(a, b);
}

int main(int argc, char *argv[]) {
    char **str = NULL; 
    int i, n, j;
    char buf[BUFSIZE + 1]; 

    printf("Enter an integer n: ");
    //stores input into a character array. BUFSIZE is the maximum number of characters to read, buf is where the input will be stored, stdin is to read input from the keyboard
    //fgets(buf, BUFSIZE, stdin);

    //loops the user until they enter a valid integer
    while(fgets(buf, BUFSIZE, stdin)){
	 //so basically it works by buf is the where the input was stored from fgets so if the user types "hi" sscanf expects %d which is an integer so it will not return 1 so it will make you go to the else loop however if the use types "1" it will store in j and sscanf will be equal to 1 and break
    	if(sscanf(buf, "%d", &j)==1)
		break;
	else
		printf("Input not interger.Retry: " );
    }
    n = atoi(buf); //turns buf into an interger

    str = malloc(n * sizeof(char *)); //memory allocator

    for (i = 0; i < n; i++) {
        printf("Enter str %d:\n", i + 1);
        fgets(buf, BUFSIZE, stdin);

        // allocate memory for each string
        str[i] = malloc(strlen(buf) + 1); //allocating memory
        strcpy(str[i], buf); //(source, destination) so it copys the source string into the destination buffer
    }

    qsort(str, n, sizeof(char *), cmp); //sorts the strings

    printf("Sorted str:\n");
    for (i = 0; i < n; i++) {
        printf("%s", str[i]);
    }

    return 0;
}
