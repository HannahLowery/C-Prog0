//prog2.c
//Hannah Lowery
//a C program thatincludes simple C functions my_openit() and my_closeit() that match the types of the function pointers in the structure:

#include <stdio.h>
#include<string.h>
#include <stdlib.h>

int my_openit(char *name, int prot);
void my_closeit(void);

typedef struct funcs{

	int (*openit)(char *name, int prot);
	void (*closeit)(void);
}funcs;


int my_openit(char *name, int prot){
	printf("my_openit:\n Name:  %s prot: %d\n", name, prot);
	return 0;
}

void my_closeit(void){
	printf("my_closeit: \n");
}

void f(struct funcs *s){
	s -> openit = my_openit;
	s->closeit=my_closeit;
}

int main(){

	 struct funcs simpletype={
		.openit = my_openit,
		.closeit= my_closeit
	};

	simpletype.openit("sofie", 5);
	simpletype.closeit();

	struct funcs s;
	f(&s);
	 
	s.openit("John", 9);
	s.closeit();

	
	f(&s);

	return 0;
}

