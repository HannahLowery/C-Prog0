//prog5.c
//accepts a single command line arguement of the file to be processed
//Hannah Lowery

//Compile: gcc -Wall -o prog5 prog5.c
//Execute: ./prog5

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]){
	
	int i;

	
	//i put if argc ==2 because the first line is the cmd argument name 
	if(argc ==2){

		printf("You entered file name: %s\n",argv[1]);//argv[1] is the first command line argument after the command line name 

		FILE *file = fopen(argv[1], "r"); //"r" so its read only'
						  //
		/*if fopen() == 0 there is no file to open*/
		if(file ==0){
		
			puts("Error:  file can't be opened\n");
		}
		else{
						///determining number of bytes using fseek()
			///SEEK_END measn the end of the file
			///fseek(File *pointer, long int offset, int position)
			fseek(file, 0L, SEEK_END);
			///ftell() returns a long integer of file position in bytes
			///ftell(File *stream)
			long int bytesOfFile = ftell(file);

			printf("Your file is %ld bytes\n", bytesOfFile);

			char *cString;
			//convert from long to size_t
			size_t slength = (size_t) bytesOfFile;

						
			cString = malloc(slength +1);//allocate memory
			fseek(file, 0L, SEEK_SET);//go back to the beginning of the file

			//fread(buffer where data will be stored, size of each element in bytes, count of elements to be read, pointer to the file stream)
			fread(cString,1,slength,file); //stores the text from file into cString
	
			fclose(file); //close file
			cString[slength]='\0';

			printf("Your file output before tokenizing: %s\n",cString);

			//tokenize string
			char delimiter[]=" -\n\t,";//used to tell what to tokenize

			char *token=strtok(cString, delimiter);
			
			printf("Your file output after tokenizing: \n");
			while(token){
			
				printf("%s\n",token);
				token=strtok(NULL, delimiter);//free string
			}
		}
	}

	else{
		puts("error: command line argument is ommitted\n");
	}
		
	
	return 0; 
}
