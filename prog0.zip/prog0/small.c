//printing x pattern in as small as code as possible, that outputs no more than a single character at a time Using a 2D array
//Hannah Lowery
//small.c
//
//to reveal characters: wc -c small.c
//compile: gcc -Wno-error=implicit-function-declaration -o small small.c
//execute: ./small

#include <stdio.h>

int main(int argc, char *argv[]){
//rowsxcolumns
char arrX[5][5]={{'X', 'X', 'X', 'X', 'X'}, {'X', 'X', 'X', 'X', 'X'},{'X', 'X', 'X', 'X', 'X'},{'X', 'X', 'X', 'X', 'X'},{'X', 'X', 'X', 'X', 'X'}};


	for (int i=0;i<5;i++){
	
		//idention for every other row starting with the first one
		if(i==0||i==2||i==4){
			
			putchar(' ');
				}
		//print the Row
		for(int j=0; j<5;j++){
		
			putchar(arrX[i][j]);
			putchar(' ');
		}
		//newline at end of row
		putchar('\n');

	
	}


 		
	
		
	return 0;
}
