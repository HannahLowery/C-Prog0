//prog3.c
//Hannah Lowery
//statically declared array

#include <stdio.h>


int array[]= {1,3,15,19,0,43,12};
#define TOTAL_ELEMENTS ((int)(sizeof(array)/sizeof(array[0])))

int main(int argc, char *argv[]){

	int i;

	for(i=-1;i <= TOTAL_ELEMENTS -2;i++){
		printf("Element %d has value %d\n",i+1,array[i+1]);
	}

	return 0;
}
